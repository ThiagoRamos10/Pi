/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ObjetoThiago;

/**
 *
 * @author Aluno
 */
public class CadastrodeClienteThiago {
    public static void main (String[] args) {
        
        ClasseClienteThiago c1 = new ClasseClienteThiago("012.345.678-90", "Jose da Silva", false,
                "81-9999-9999");
        
        ClasseClienteThiago c2 = new ClasseClienteThiago( "012.345.678.90", "Maria da Silva", true,
                "81-9999-9999");
        ClasseClienteThiago c3 = new ClasseClienteThiago( "092.823.334.85", "Thiago Ramos", false, 
        "81-9987-9922");

                  
       System.out.println("CPF:"+c1.getCpf());
       System.out.println("Nome: "+c1.getNome());
       System.out.println("Sexo:"+c1.getSexo());
       System.out.println("Sexo:"+c1.getTelefone());
       
        System.out.println("CPF:"+c2.getCpf());
       System.out.println("Nome: "+c2.getNome());
       System.out.println("Sexo:"+c2.getSexo());
       System.out.println("Sexo:"+c2.getTelefone());
       
        System.out.println("CPF:"+c3.getCpf());
       System.out.println("Nome: "+c3.getNome());
       System.out.println("Sexo:"+c3.getSexo());
       System.out.println("Sexo:"+c3.getTelefone());
               
    }
    
}
