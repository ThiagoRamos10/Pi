/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ObjetoThiago;

/**
 *
 * @author Aluno
 */
public class ClasseClienteThiago {
    
    //atributos
    private String cpf;
    private String nome;
    private boolean sexo;
    private String telefone;
    
    
    //construtor
    public ClasseClienteThiago (String cpf, String nome, boolean sexo, String telefone){
            this.cpf = cpf;
            this.nome = nome;
            this.sexo = sexo;
            this.telefone = telefone;
           
}

    public String getCpf(){
        return cpf;
    
    }
    
    public void setCpf(){
        this.cpf = cpf;
    }
            
            
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSexo() {
        if (sexo == false) return "Masculino";
        else{
        return "Feminino";
                }
    }

    public void setSexo(boolean sexo) {
        this.sexo = sexo;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
   
}